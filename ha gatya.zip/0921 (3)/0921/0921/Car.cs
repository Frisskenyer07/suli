﻿using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Xml.Linq;

namespace _0921
{
    internal class Car
    {
        public Guid Id { get; private set; }
        private string licencePlate;
        private string brand;
        private string model;
        private int manufactureYear;
        private decimal dailyRentalPrice;
        private int mileage;

        public string LicencePlate 
        { 
            get => licencePlate;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentException(nameof(LicencePlate), " nem lehetnek null, üresek vagy csak szóközökből állók.");
                }
                value.Trim().ToLower();
                licencePlate = value;
            }
        }

        public string Brand 
        { 
            get => brand;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentException(nameof(Brand), " nem lehetnek null, üresek vagy csak szóközökből állók.");
                }
                brand = value;
            }
        }

        public string Model 
        { 
            get => model;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentException(nameof(Model), " nem lehetnek null, üresek vagy csak szóközökből állók.");
                }
                model = value;
            }
        }

        public int ManufactureYear 
        { 
            get => manufactureYear;
            private set
            {
                if (value < 1990 || value > DateTime.Now.Year)
                {
                    throw new ArgumentException(nameof(ManufactureYear), $"Az év 1990 és {DateTime.Now.Year} közé kell esnie.");
                }
                manufactureYear = value;
            }
        }

        public decimal DailyRentalPrice 
        { 
            get => dailyRentalPrice;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(nameof(DailyRentalPrice), "Az érték nem lehet negativ");
                }
                dailyRentalPrice = value;
            }
        }

        public int Mileage 
        { 
            get => mileage;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(nameof(Mileage), "Az érték nem lehet negatív");
                }
                mileage = value;
            }
        }

        public List<User> Users
        {
            get;
            private set;
        }

        public const decimal VatRate = 0.27m;

        public bool IsAvailable 
        { 
            get;
            private set;
        }

        public void AddUser(User user)
        {
            if (user == null)
            {
                throw new Exception("A hozzáadott érték nem lehet üres");
            }
            else if(user == user)
            {
                throw new Exception("A hozzáadott érték már létezik");
            }
            Users.Add(user);
        }




    }
}
