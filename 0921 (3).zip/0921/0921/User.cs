﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace _0921
{
    internal class User
    {
        private Guid id;
        public Guid Id { get; private set; }
        private string name;
        public string Name 
        {
            get => name;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentException(nameof(Name), "A felhasználó teljes neve, nem lehet üres");
                }
                name = value;
            }
        }
        private string email;
        public string Email 
        { 
            get => email;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentException(nameof(Email), "Az email nem lehet üres.");
                }
                email = value;
            }
        }
        private string department;

        public User(string name, string email)
        {
            Name = name;
            Email = email;
            Department = "ismeretlen";
        }
        public User(string name, string email, string department) : this (name, email)
        {
            Department = department;
        }

        public string Department 
        { 
            get; 
            private set; 
        }

        public override string ToString()
        {
            return $" Név: {Name} | E-mail: {Email} | Osztály: {Department}";
        }

    }
}
