﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;
using System.Xml;

namespace _0921
{
    internal class Company
    {
       

        public Company(string name, string taxNumber)
        {
            Id = Guid.NewGuid();
            Name = name;
            TaxNumber = taxNumber;
            Address = "ismeretlen";
        }

        public Company(string name, string taxNumber, string address, Car car) :this(name, taxNumber)
        {
            Address = address;
        }
        private Guid id;
        public Guid Id { get; private set; }

        private string name;
        public string Name 
        {
            get => name;
            private set 
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentOutOfRangeException(nameof (Name), "A cég neve, nem lehet null, üres vagy csak szóköz ");
                }
                name = value;
            }
        }

        private string taxNumber;
        public string TaxNumber 
        { 
            get => taxNumber;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentOutOfRangeException(nameof(TaxNumber), "Adószám, nem lehet null, üres vagy csak szóköz ");
                }
                taxNumber = value;
            }
             
        }

        private string address;
        public string Address 
        { 
            get;
            private set;
            
        }

        public List<Car> Cars
        {
            get;
            private set;
        }


        public void AddCar(Car car)
        {
            if (car == null)
            {
                throw new Exception("A hozzáadott érték nem lehet üres")
            }
            Cars.Add(car);
        }

        public override string ToString()
        {
            return $"„Cég neve: {Name} | Adószám: {TaxNumber} | Székhely: {Address} | Autók száma: {Cars.Count} db";
        }



    }
}
