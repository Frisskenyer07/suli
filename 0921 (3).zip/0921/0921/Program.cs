﻿namespace _0921
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
