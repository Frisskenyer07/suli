﻿using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Xml.Linq;

namespace _0921
{
    internal class Car
    {
        public Guid Id { get; private set; }
        private string licencePlate;
        private string brand;
        private string model;
        private int manufactureYear;
        private decimal dailyRentalPrice;
        private int mileage;

        public string LicencePlate 
        { 
            get => licencePlate;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentException(nameof(LicencePlate), " nem lehetnek null, üresek vagy csak szóközökből állók.");
                }
                value.Trim().ToLower();
                licencePlate = value;
            }
        }

        public string Brand 
        { 
            get => brand;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentException(nameof(Brand), " nem lehetnek null, üresek vagy csak szóközökből állók.");
                }
                brand = value;
            }
        }

        public string Model 
        { 
            get => model;
            private set
            {
                if (value.Trim().Length == 0 || value.Trim() == null || value == " ")
                {
                    throw new ArgumentException(nameof(Model), " nem lehetnek null, üresek vagy csak szóközökből állók.");
                }
                model = value;
            }
        }

        public int ManufactureYear 
        { 
            get => manufactureYear;
            private set
            {
                if (value < 1990 || value > DateTime.Now.Year)
                {
                    throw new ArgumentException(nameof(ManufactureYear), $"Az év 1990 és {DateTime.Now.Year} közé kell esnie.");
                }
                manufactureYear = value;
            }
        }

        public decimal DailyRentalPrice 
        { 
            get => dailyRentalPrice;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(nameof(DailyRentalPrice), "Az érték nem lehet negativ");
                }
                dailyRentalPrice = value;
            }
        }

        public int Mileage 
        { 
            get => mileage;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(nameof(Mileage), "Az érték nem lehet negatív");
                }
                mileage = value;
            }
        }

        public const  decimal VatRate = 0.27m;

        public List<User> Users
        {
            get;
            private set;
        }

        private Company carCompany;
        public Company CarCompany 
        { 
            get => carCompany;
            private set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(nameof(CarCompany), "nem lehet ures.");
                }
                carCompany = value;
            }
        }

        private int age;
        public int Age 
        {
            get => manufactureYear;
            private set
            {
                age = DateTime.Now.Year - value;
            }
        }

        private decimal vatIncludedPrice;
        public decimal VatIncludedPrice 
        {
            get => DailyRentalPrice;
            private set
            {
                vatIncludedPrice = value * VatRate;
            }
        }

        private int userCount;

        public Car(string licencePlate, string brand, string model, int manufactureYear, decimal dailyRentalPrice)
        {
            Id = Guid.NewGuid();
            LicencePlate = licencePlate;
            Brand = brand;
            Model = model;
            ManufactureYear = manufactureYear;
            Mileage = 0;
            DailyRentalPrice = dailyRentalPrice;
            
        }
        public Car(string licencePlate, string brand, string model, int manufactureYear, decimal dailyRentalPrice, int mileage) :this(licencePlate, brand, model, manufactureYear, dailyRentalPrice)
        { 
            Mileage = mileage;
            
        }


        public List<User> UserCount 
        {
            get => Users;
            private set
            {
                userCount = Users.Count;
            }
        }




    }
}
