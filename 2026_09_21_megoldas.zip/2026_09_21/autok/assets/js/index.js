const landingContainer = document.querySelector('#landing-container');

async function loadLanding() {
    try {
        const response = await fetch('./assets/json/landing.json');
        if (!response.ok) throw new Error('A landing adatok nem tölthetők be.');

        const items = await response.json();

        landingContainer.innerHTML = items.map((item, index) => `
            <article class="landing-card ${index === 0 ? 'landing-card--featured' : ''}">
                <div class="landing-card__image" style="background-image: url('${item.image}')"></div>
                <div class="landing-card__content">
                    <span class="landing-card__number">0${index + 1}</span>
                    <h2>${escapeHtml(item.title)}</h2>
                    <p>${escapeHtml(item.description)}</p>
                </div>
            </article>
        `).join('');
    } catch (error) {
        landingContainer.innerHTML = `<p class="status-message status-message--error">${escapeHtml(error.message)}</p>`;
    }
}

function escapeHtml(value) {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

loadLanding();
