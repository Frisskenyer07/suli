const carsContainer = document.querySelector('#cars-container');
const searchInput = document.querySelector('#car-search');
const resultCount = document.querySelector('#result-count');
const noResults = document.querySelector('#no-results');
const modal = document.querySelector('#car-modal');
const modalContent = document.querySelector('#modal-content');
const modalClose = document.querySelector('#modal-close');

let cars = [];

async function loadCars() {
    try {
        const response = await fetch('../assets/json/cars.json');
        if (!response.ok) throw new Error('Az autó adatok nem tölthetők be.');

        cars = await response.json();
        renderCars(cars);
    } catch (error) {
        carsContainer.innerHTML = `<p class="status-message status-message--error">${escapeHtml(error.message)}</p>`;
    }
}

function renderCars(list) {
    resultCount.textContent = `${list.length} autó található`;
    noResults.classList.toggle('hidden', list.length !== 0);

    carsContainer.innerHTML = list.map((car, index) => `
        <button class="car-card" type="button" data-index="${cars.indexOf(car)}">
            <div class="car-card__image" style="background-image: url('${car.image_url}')"></div>
            <div class="car-card__body">
                <h2>${escapeHtml(car.name)}</h2>
                <p>Gyártási év: <strong>${car.manufacturing_year}</strong></p>
                <span class="car-card__link">Részletek →</span>
            </div>
        </button>
    `).join('');
}

function openModal(car) {
    modalContent.innerHTML = `
        <div class="modal__hero" style="background-image: url('${car.image_url}')"></div>
        <div class="modal__body">
            <span class="modal__eyebrow">Autó adatlap</span>
            <h2>${escapeHtml(car.name)}</h2>
            <div class="modal__grid">
                <div><span>Gyártási év</span><strong>${car.manufacturing_year}</strong></div>
                <div><span>Életkor</span><strong>${car.age} év</strong></div>
                <div><span>Helyszín</span><strong>${escapeHtml(car.location)}</strong></div>
            </div>
            <div class="modal__description">
                <h3>Leírás</h3>
                <p>${escapeHtml(car.description)}</p>
            </div>
        </div>
    `;

    modal.classList.remove('hidden');
    document.body.classList.add('modal-open');
}

function closeModal() {
    modal.classList.add('hidden');
    document.body.classList.remove('modal-open');
}

searchInput.addEventListener('input', (event) => {
    const query = event.target.value.trim().toLowerCase();
    const filtered = cars.filter((car) =>
        car.name.toLowerCase().includes(query)
    );
    renderCars(filtered);
});

carsContainer.addEventListener('click', (event) => {
    const card = event.target.closest('.car-card');
    if (!card) return;

    const car = cars[Number(card.dataset.index)];
    if (car) openModal(car);
});

modalClose.addEventListener('click', closeModal);
modal.addEventListener('click', (event) => {
    if (event.target === modal) closeModal();
});

document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !modal.classList.contains('hidden')) {
        closeModal();
    }
});

function escapeHtml(value) {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

loadCars();
